;
(function (w) {
  var businessUrls = APP_CONSTANTS.businessUrls;

  // 当调用网络出现405错误时,表示登录失效,则转到登录界面
  JSBridge.registerFunction("netErrorEvent", function (error) {
    // 登录失效
    if (error && error.httpCode == 405) {
      // CustomerUtils.clear();
      // $.toast.fail('登录已失效',2000,function(){
      //     JSBridge.forward.inside({
      //         url: businessUrls.login,
      //         newView: true
      //     });
      // });

      return false;
    }
  });

  w.CustomerUtils = (function () {
    var storage = localStorage;
    var cookie = (function () {
      return {
        set: function (key, value, expires) {
          var newCookie = key + "=" + value + ";path=/"
          if (expires) {
            expires = Date.now() + (expires * 1000);
            newCookie += ";expires=" + new Date(expires).toGMTString()
          }
          document.cookie = newCookie;
        },
        delete: function (key) {
          document.cookie = key + "=" + ";path=/";
        },
        get: function (key) {
          var cs = document.cookie.split(";");
          var map = cs ? (function () {
            var m = {};
            cs.forEach(function (v, i) {
              var kv = v.split("=");
              m[kv[0]] = kv[1];
            });
            return m;
          })() : {};

          return map[key];
        }
      };
    })();

    JSBridge.registerFunction("updateLoginState", function (state) {
      if (state) {
        storage.setItem("isLoged", true);
        cookie.set("isLoged", "1", 31536000); // 365 * 24 * 60 *60
      } else {
        storage.removeItem("isLoged");
        cookie.delete("isLoged");
      }
    });

    function save(customer, callback) {
      JSBridge.driver.clearCookie();
      storage.setItem("isLoged", true);
      JSBridge.cache.save("customer", customer, 1);
      cookie.set("isLoged", "1", 31536000); // 365 * 24 * 60 *60
      JSBridge.notification.loginNotify();
    }

    function isLoged() {
      if ($.appVersion().isApp && $.appVersion().isAndroid) {
        return !!CustomerUtils.getCustomer();
      }

      var isLoged = storage.getItem("isLoged");
      if (!isLoged) {
        isLoged = cookie.get("isLoged") === "1";
      }
      return Boolean(isLoged);
    }

    function isLogedSync() {
      return new Promise(function (resolve, reject) {
        var isLoge = CustomerUtils.isLoged();
        (isLoge ? resolve : reject)();
      });
    }

    function clear() {
      JSBridge.driver.clearCookie();
      storage.removeItem("isLoged");
      JSBridge.cache.delete("customer");
      cookie.delete("isLoged");
      JSBridge.notification.logoutNotify();
    }

    function getCustomer() {
      return JSBridge.cache.get("customer");
    }

    function getCustomerSync() {
      return JSBridge.cache.getSync("customer");
    }

    function loadCustomer(fn) {
      JSBridge.net.invoke({ //调用用户信息接口
        loading: false,
        url: "public/users/userInfo",
        success: function (result) {
          var customer = result;
          if (Root('ENV_MODEL') === "dev") {
            JSBridge.cache.getSync("customer").then(function (data) {
              JSBridge.cache.save("customer", Object.assign({}, data, customer), 1)
            });
          }
          fn(customer);
        },
        error: function (error) {
          error && $.toast.fail(error.message);
          fn();
        }
      });
    }

    JSBridge.registerFunction("LoginOut", function () {
      JSBridge.cache.delete("customer");
      storage.removeItem("isLoged");
      cookie.delete("isLoged");
      JSBridge.driver.clearCookie();
      JSBridge.notification.logoutNotify();
    });

    return {
      save: save,
      isLoged: isLoged,
      isLogedSync: isLogedSync,
      clear: clear,
      getCustomer: getCustomer,
      getCustomerSync: getCustomerSync,
      loadCustomer: loadCustomer
    };
  })();

  function fillurl(url) {
    if (!url) {
      return "";
    }

    if (!/^https?:\/\//.test(url)) {
      url = "http://" + url;
    }

    if (!/\/$/.test(url)) {
      url += "/";
    }

    return url;
  }

  w.OtherUtils = {
    /* 手机号中间4位加星号 */
    mixPhone: function (phone) {
      return phone.substring(0, 3) + '****' + phone.substring(7);
    },
    mixBankCardNo: function (bankCardNo) {
      return bankCardNo.substring(0, 4) + '***********' + bankCardNo.substring(15);
    },
    getPath: function () {
      var _from = location.href.split("\/").slice(-2).join("\/");
      return encodeURIComponent(_from);
    },
    formatOutsideUrl: function (url) {
      return url.match(/^http/) || !url.match(/^[\w]+\.htm/) ? url : OtherUtils.getDomain() + url;
    },
    formatOutsideUrlSync: function (url) {
      return new Promise(function (resolve, reject) {
        if (url.match(/^http/) || !url.match(/^[\w]+\.htm/)) {
          return resolve(url);
        }
        OtherUtils.getDomainSync().then(function (domain) {
          resolve(domain + url);
        });
      });
    },
    getStaticurl: (function () {
      var staticurl;
      return function () {
        if (!staticurl) {
          staticurl = JSBridge.cache.get("staticurl");

          if (!staticurl) {
            staticurl = JSBridge.cache.get("cdnurl");
            if (!staticurl) {
              staticurl = OtherUtils.getDomain();
            }
          }

          if (staticurl) {
            staticurl = fillurl(staticurl);
            JSBridge.cache.save("staticurl", staticurl);
          } else {
            staticurl = fillurl(location.host);
          }
        }
        return staticurl;
      };
    })(),
    getStaticurlSync: (function () {
      var staticurl;
      return function () {
        return new Promise(function (resolve, reject) {
          if (staticurl) {
            return resolve(staticurl);
          }
          JSBridge.cache.getSync("staticurl").then(function (result) {
            if (result) {
              return result;
            }
            return JSBridge.cache.getSync("cdnurl");
          }).then(function (result) {
            if (result) {
              return result;
            }
            return OtherUtils.getDomainSync();
          }).then(function (result) {
            staticurl = fillurl(result);
            JSBridge.cache.save("staticurl", staticurl);
            resolve(staticurl);
          })
        })
      }
    })(),
    getDomain: (function () {
      var domain;
      return function () {
        if (!domain) {
          domain = JSBridge.cache.get("domain");
          domain = fillurl(domain);
        }
        return domain;
      };
    })(),
    getDomainSync: (function () {
      var domain;
      return function () {
        return new Promise(function (resolve, reject) {
          if (domain) {
            return resolve(domain);
          }
          JSBridge.cache.getSync("domain").then(function (result) {
            domain = fillurl(result || location.host);
            resolve(domain)
          })
        });
      }
    })()
  };


  // 添加拦截器，如果是页面的网络请求，则不允许显示原生的loading效果
  ;(function (stealthys) {
    if (!stealthys || !stealthys.length) {
      return;
    }

    var currentUrl = decodeURIComponent(OtherUtils.getPath());

    if (!stealthys.includes(currentUrl)) {
      return;
    }

    JSBridge.registerFunction("invoke.net.invoke", function (settings) {
      settings.data.loading = false;
      settings.loading = false;
    });
  })(APP_CONSTANTS.stealthyNetUrls);

  /**
   * 上报用户行为信息
   */
  // ;(function () {
  //   if (!$.appVersion().isApp) {
  //     return;
  //   }
  //
  //   /**
  //    * 调用接口,上报信息
  //    */
  //   function reportDynatrace(settings) {
  //     var sessionId,
  //       deviceId,
  //       login_name,
  //       url,
  //       urlSplit,
  //       customer,
  //       params = [];
  //
  //     Promise.all([
  //       JSBridge.driver.getSessionIdSync(),
  //       JSBridge.driver.deviceInfoSync(),
  //       CustomerUtils.getCustomerSync().then(function (customer) {
  //         return customer ? customer.login_name : '';
  //       }),
  //       new Promise(function (resolve, reject) {
  //         urlSplit = settings.url.split("?");
  //         url = urlSplit[0];
  //         if (urlSplit.length > 1) {
  //           urlSplit[1].split("&").forEach(function (v, i) {
  //             if (v && (!/^((user|app)Token|accountName)=.*/.test(v))) {
  //               params.push(v);
  //             }
  //           })
  //
  //           if (params.length) {
  //             url += "?" + params.join("&");
  //           }
  //         }
  //         resolve(url);
  //       })
  //     ]).then(function (results) {
  //       if (results[2] != "" && results[2] != undefined && results[2] != null) {
  //         JSBridge.net.invokeSync("app/dynatrace", {
  //           app_sess_id: results[0].data.sessionId,
  //           device_id: results[1].data.drice_id,
  //           loading: false,
  //           login_name: results[2],
  //           page_name: results[3],
  //           click_time: Date.format(new Date(), "yyyy-MM-dd HH:mm:ss"),
  //           action_data: settings.remark || "APP原生跳转"
  //         });
  //       }
  //     }).catch(function (error) {
  //       console.log(error)
  //     });
  //   }
  //
  //   /**
  //    * 当内部页面被加载时出发上报用户行为信息
  //    */
  //   JSBridge.loadFinish(function () {
  //     if (OtherUtils.getPath() == "customer%2Fshare.htm") {
  //       return
  //     }
  //     reportDynatrace({
  //       url: decodeURIComponent(OtherUtils.getPath()),
  //       remark: ""
  //     });
  //   });
  //
  //   /**
  //    * 当调用外部跳转时触发上报用户行为信息
  //    */
  //   JSBridge.registerFunction("invoke.forward", function (fData) {
  //     if (fData.type != "forward.outside") {
  //       return;
  //     }
  //
  //     var remark = "外部页面";
  //
  //     if (fData.data.gameType) {
  //       remark = "进入游戏: " + fData.data.gameType;
  //       if (/(gameType|gameId)\=(fish|6)/.test(fData.data.url)) {
  //         remark = "进入游戏: 捕鱼王2";
  //       }
  //     }
  //
  //     reportDynatrace({
  //       url: fData.data.url,
  //       remark: remark
  //     });
  //   });
  //
  //   /**
  //    * 当调用本地化AGQJ游戏时,上报用户行为
  //    */
  //   JSBridge.registerFunction("invoke.driver.game", function (fData) {
  //     reportDynatrace({
  //       url: "local AGQJ",
  //       remark: "进入游戏: AGQJ"
  //     });
  //   });
  // })();
})(window);
