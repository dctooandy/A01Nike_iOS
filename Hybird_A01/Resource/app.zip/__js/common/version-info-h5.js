
 window.VERSION_INFO_H5 = {
     "version": "0NaNaNaNaNaNaN-9a73c99b0e10f16fcfce2de2d6eb8c3e206fc765",
     "buildtime": "2019-12-28 16:17:18"
 }
 