
 window.VERSION_INFO_H5 = {
     version: '20181027162824-28082',
     buildtime: '2018-10-29 09:04:00'
 }
 