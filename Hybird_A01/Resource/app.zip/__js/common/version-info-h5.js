
 window.VERSION_INFO_H5 = {
     version: '0NaNaNaNaNaNaN-',
     buildtime: '2018-12-05 15:24:48'
 }
 