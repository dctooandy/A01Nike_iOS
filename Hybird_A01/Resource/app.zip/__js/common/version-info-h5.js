
 window.VERSION_INFO_H5 = {
     version: '20181121090135-28886',
     buildtime: '2018-11-21 09:02:34'
 }
 