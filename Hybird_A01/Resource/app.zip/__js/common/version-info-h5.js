
 window.VERSION_INFO_H5 = {
     version: '20190109112846-a01ab35b47a6f4fb8aa07d680ce0e42c52acdf6f',
     buildtime: '2019-01-09 11:29:25'
 }
 