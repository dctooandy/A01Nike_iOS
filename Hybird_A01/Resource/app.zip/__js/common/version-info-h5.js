
 window.VERSION_INFO_H5 = {
     "version": "0NaNaNaNaNaNaN-d5f5f6d4f03a6ebb92addddf1164c21978005b0a",
     "buildtime": "2019-12-28 13:05:11"
 }
 