
 window.VERSION_INFO_H5 = {
     version: '0NaNaNaNaNaNaN-38a65c1d259678d379c5b5077f6b54b12021a89c',
     buildtime: '2019-01-17 16:20:56'
 }
 