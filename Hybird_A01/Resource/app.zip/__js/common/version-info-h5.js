
 window.VERSION_INFO_H5 = {
     version: '0NaNaNaNaNaNaN-621fbcabf3e1fe51d03c0f47f1c3c5dd06ca519b',
     buildtime: '2019-08-01 17:33:52'
 }
 