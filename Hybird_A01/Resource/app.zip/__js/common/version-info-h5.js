
 window.VERSION_INFO_H5 = {
     version: '0NaNaNaNaNaNaN-',
     buildtime: '2018-11-27 11:58:50'
 }
 