
 window.VERSION_INFO_H5 = {
     version: '0NaNaNaNaNaNaN-c54f4f38fc63dc1c733fdb9f64f67674ca69aca6',
     buildtime: '2019-01-14 18:59:09'
 }
 