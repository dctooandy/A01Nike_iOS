
 window.VERSION_INFO_H5 = {
     version: '0NaNaNaNaNaNaN-e72e1b732c5bc332d03f8a42eeff6d8cd11f6212',
     buildtime: '2020-01-13 15:18:35'
 }
 